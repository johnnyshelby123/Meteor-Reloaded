import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.arguments.StringArgumentType;
import meteordevelopment.meteorclient.commands.Command;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.component.DataComponentTypes;
import java.util.List;
import java.util.ArrayList;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class SetLoreCommand extends Command {

    public SetLoreCommand() {
        super("setlore", "Sets the lore for the item in your hand.", "sl");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(argument("lore", StringArgumentType.greedyString())
            .executes(this::executeSetLore)
        );
    }

    private int executeSetLore(CommandContext<CommandSource> context) {
        if (!validBasic()) return SINGLE_SUCCESS;

        ItemStack stack = MinecraftClient.getInstance().player.getMainHandStack();
        if (stack == null || stack.isEmpty()) {
            error("You must hold an item in your main hand.");
            return SINGLE_SUCCESS;
        }

        String loreText = StringArgumentType.getString(context, "lore").trim();
        if (loreText.isEmpty()) {
            error("Please provide a lore text.");
            return SINGLE_SUCCESS;
        }

        List<Text> lore = new ArrayList<>();
        lore.add(Text.literal(loreText).styled(style -> style.withBold(true).withItalic(true).withColor(Formatting.GREEN)));

        ItemStack modifiedStack = stack.copy();
        modifiedStack.set(DataComponentTypes.LORE, List.copyOf(lore));  // Create an immutable copy of the lore list

        setStack(modifiedStack);

        info("Lore set to: " + loreText);
        return SINGLE_SUCCESS;
    }

    private void setStack(ItemStack stack) {
        if (MinecraftClient.getInstance().player != null && MinecraftClient.getInstance().player.getAbilities().creativeMode) {
            int slot = MinecraftClient.getInstance().player.getInventory().getSelectedSlot();
            MinecraftClient.getInstance().player.networkHandler.sendPacket(new CreativeInventoryActionC2SPacket(36 + slot, stack));
            MinecraftClient.getInstance().player.getInventory().setStack(slot, stack);
        }
    }

    private boolean validBasic() {
        if (MinecraftClient.getInstance().player == null) {
            error("Player is not available.");
            return false;
        }
        if (!MinecraftClient.getInstance().player.getAbilities().creativeMode) {
            error("Creative mode only.");
            return false;
        }
        return true;
    }
}
